from flask import Flask, request, render_template, jsonify
import sqlite3

conn = pymysql.connect(
    host='cheng',  
    port=3306,  
    user='root',  
    password='446537',  
    database='calculator'  
)

app = Flask(__name)


cursor = conn.cursor()

# 创建计算历史表
cursor.execute('''
    CREATE TABLE IF NOT EXISTS calculation_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        expression TEXT,
        result REAL
    )
''')
conn.commit()

@app.route('/')
def index():
    return render_template('calculator.html')

@app.route('/saveCalculation', methods=['POST'])
def save_calculation():
    data = request.get_json()
    expression = data.get('expression')
    result = data.get('result')

    try:
        # 在后端执行计算
        calculation_result = eval(expression)

        # 保存计算历史到数据库
        cursor.execute('INSERT INTO calculation_history (expression, result) VALUES (?, ?)', (expression, calculation_result))
        conn.commit()

        return jsonify({'message': 'Calculation successful', 'result': calculation_result})
    except Exception as e:
        return jsonify({'message': 'Calculation error', 'error': str(e)})

@app.route('/getCalculationHistory', methods=['GET'])
def get_calculation_history():
    # 获取计算历史记录
    cursor.execute('SELECT expression, result FROM calculation_history')
    history = cursor.fetchall()
    return jsonify({'data': history})

if __name__ == '__main__':
    app.run(debug=True)
